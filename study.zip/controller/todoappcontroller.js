const TodoAppservice = require('../service/TodoAppservice')

function index(req,res){
    res.send('hello nodejs')
}


// title, contents, done 받아서 db에 저장
async function saveTodo(req,res){
    const title = req.body.title
    const contents = req.body.contents
    const done = req.body.done

    if(title == null || contents == null || done == null){
        res.status(400).send({message: '올바른 파라미터를 넘겨주세요'})
        return;
    }
    await TodoAppservice.insertTodo(title,contents,done);
    res.sendStatus(200);
}

// 리스트 전체 조회
async function todolist(req,res){
    // 전체 todo를 반환함
    const todo = await TodoAppservice.findAllTodolist();
    res.status(200).send(todo)
}

async function updateTodo(req,res){
    const id = req.body.id
    const title = req.body.title
    const contents = req.body.contents
    const done = req.body.done

    if(id == null || title == null || contents == null || done == null){
        res.status(400).send({message : '올바른 파라미터를 넘겨주세요'})
        // return을 쓰기 싫으면 else문으로 넘어가도 된다.
        return;
    }

    try{
        await TodoAppservice.updateTodo(id,title,contents,done)
        res.sendStatus(200);
    } catch (e){
        res.status(400).send({message : e})
    }
}

async function deleteTodo(req,res){
    const id = req.params.id;

    if(id == null){
        res.status(400).send({message: '올바른 아이디를 넘겨주세여'})
        return;
    }

    try{
        await TodoAppservice.deleteTodo(id)
        res.sendStatus(200);
    } catch (e){
        res.status(400).send({message : e})
    }
}

exports.index = index;
exports.saveTodo = saveTodo;
exports.todolist = todolist;
exports.updateTodo = updateTodo;
exports.deleteTodo = deleteTodo;