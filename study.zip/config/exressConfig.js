const express = require('express');
const session = require('express-session');

const path = require('path');
const todoappController = require('../controller/todoappcontroller');
const TodoAppLogincontroller = require('../controller/TodoappLogincontroller')



function init() {

  const app = express();
  app.use(express.json());
  app.use(express.urlencoded());

  app.use(session({
    secret: 'my-secret-key', 
    resave: false,
    saveUninitialized: true,
    cookie: {
      secure: false, // https를 사용하는 경우 true로 변경해준다.
      maxAge: 3600000 // 1시간
    }
  }));

  // 정적파일 제공
  app.use('/view', express.static('C:\\Users\\MYCOM\\Desktop\\study\\view'));

  const router = makeAndGetrouter();
  app.use(router);
  app.listen(process.env.PORT);
}



function makeAndGetrouter() {
  const router = express.Router();

  router.get('/', (req, res) => {
    console.log(req.session.userId);
    res.sendFile(path.join(__dirname, '../view/html/main.html'));
  });

  router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../view/html/login.html'));
  })
  router.get('/sign', (req, res) => {
    res.sendFile(path.join(__dirname, '../view/html/sign.html'));
  })

  router.get('/write', (req, res) => {
    if (req.session.user) {
      res.sendFile(path.join(__dirname, '../view/html/write.html'));
      console.log(req.session.user._id);
      console.log(req.session.user.nickname);
    } else {
      res.send(`
            <script>
              alert('로그인을 해주세요');
              window.location.href = '/login';
            </script>
          `);
    }
  });



  // 회원가입
  router.post('/sign', TodoAppLogincontroller.sign)

  // 회원가입 아이디 중복확인
  router.post('/id-check', TodoAppLogincontroller.id_check)

  // 로그인
  router.post('/login', TodoAppLogincontroller.login)






  // router.post('/', todoappController.saveTodo);
  // router.put('/', todoappController.updateTodo);
  // router.delete('/:id', todoappController.deleteTodo);

  return router;
}

exports.init = init;