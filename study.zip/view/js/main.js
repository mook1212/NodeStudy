console.log(123);

document.getElementById('login').addEventListener('click',()=>{
    location.href = '/login'
})
document.getElementById('sign').addEventListener('click',()=>{
    location.href = '/sign'
})
document.getElementById('write').addEventListener('click',()=>{
    location.href = '/write'
})